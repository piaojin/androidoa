waxClass{"HomeView", UIView}

function changeLua2(self)
    local tempView = UIView:initWithFrame(CGRect(0,0,600,100))
    tempView:setBackgroundColor(UIColor:redColor())
    self:addSubview(tempView)
    local label = UILabel:initWithFrame(CGRect(0,0,600,100))
    label:setText("网络测试修改指定类(HomeView)的方法的实现！")
    tempView:addSubview(label)
end