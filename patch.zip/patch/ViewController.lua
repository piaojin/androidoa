waxClass{"ViewController", UIViewController}

function changeLua(self)
    local tempView = UIView:initWithFrame(CGRect(0,0,100,100))
    tempView:setBackgroundColor(UIColor:redColor())
    self:view():addSubview(tempView)
    local label = UILabel:initWithFrame(CGRect(0,0,600,100))
    label:setText("网络测试成功！")
    tempView:addSubview(label)
end

function initView(self)

    self:textView():setBackgroundColor(UIColor:orangeColor())
    self:textView():setText("通过waxpatch修改颜色后")

end